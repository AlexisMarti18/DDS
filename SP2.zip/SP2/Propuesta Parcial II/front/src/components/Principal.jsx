import React from "react";
import { Link } from "react-router-dom";

function Principal() {
    return (
        <div>
            <h1>Propuesta de parcial 2</h1>
            <nav class="navbar navbar-expand navbar-light bg-light">
                <div class="nav navbar-nav">
                    <Link to='/' className="ml-5 btn btn-secondary">
                        <i>Principal</i>
                    </Link>
                    <Link to='/ajuste' className="ml-5 btn btn-success">
                        <i>Ajuste Stock</i>
                    </Link>
                    <Link to='/consultaAjustes' className="ml-5 btn btn-primary">
                        <i>Consultar ajustes stock</i>
                    </Link>
                    <Link to='/consultaProductos' className="ml-5 btn btn-primary">
                        <i>Consultar productos</i>
                    </Link>
                </div>
            </nav>
            
        </div>
    )
}

export { Principal }