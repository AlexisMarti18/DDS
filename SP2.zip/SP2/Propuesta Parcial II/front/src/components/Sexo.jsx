import React from 'react'

function Sexo() {



    return (
        1
    )
}

export { Sexo }