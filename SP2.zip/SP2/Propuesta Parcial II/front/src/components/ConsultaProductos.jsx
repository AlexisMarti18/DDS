import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

function ConsultaProductos() {
    const [productos, setProductos] = useState([])

    const obtenerProductos = async () => {
        try {
            const prod = await axios.get('http://localhost:3001/productos')
            setProductos(prod.data)
        } catch (error) {
            console.error('No se pudieron cargar los productos:', error)
        }
    }

    useEffect(() => {
        obtenerProductos()
    }, [])

    return (
        <div className='container'>
            <div
                className="table-responsive"
            >
                <h3>
                    Productos
                </h3>
                <table
                    className="table table-striped table-primary align-middle"
                >
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Stock</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            productos && productos.map((e) => {  
                                return (
                                    <tr key={e.Id}>
                                        <td>{e.Id}</td>
                                        <td>{e.Nombre}</td>
                                        <td>{e.Stock}</td>
                                    </tr>
                                )
                            })
                        }
                    </tbody>
                </table>
            </div>
            <Link to='/' className='btn btn-danger'>
                    <i>Volver a principal</i>
            </Link>
        </div>
    )
}

export { ConsultaProductos }