import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function AjusteStock () {
    const [productos, setProductos] = useState([]); //usa estado

    const [productoId, setProductoId] = useState(0); //inicializar con el tipo de datos correcto
    const [fecha, setFecha] = useState('');
    const [motivo, setMotivo] = useState('');
    const [cantidad, setCantidad] = useState(0);

    const handleAceptar = async (e) => {

        e.preventDefault()

        if(motivo.length > 20 || motivo.length < 5) {
            alert('motivo mal');
            return;
        }

        const datosEnvio = {
            Producto_id: productoId,
            Fecha: fecha,
            Motivo: motivo,
            Cantidad: parseInt(cantidad)
        }

        try {
            const respuesta = await axios.post('http://localhost:3001/ajustes', datosEnvio)
            console.log('datos enviados:', respuesta.data)
        } catch (error) {
            console.error("error al enviar:", error)
        }

    }

    useEffect(() => {        // se ejecuta solo la primera vez que se ejecuta
        cargarProductos()
    }, []) //hacer direcctamente cuando se carga sin dependencia

    const cargarProductos = async() => {    // abajo de este com, va la ruta de la info
        try { //hacer trycatch!!!!!
            const {data} = await axios.get('http://localhost:3001/productos') //es async, busca productos, la info esta en prods.data
            setProductos(data) //aca guardo en el estado la lista de productos
        } catch (error) {
            
        }
    }

    return (
        <div className='container mt-4'>
            <form
                style={{maxWidth: '600px'}}
                onSubmit={handleAceptar}
            >
                <div className='form-group mb-3'>
                    <label>Producto</label>
                    <select 
                        className='form-control'
                        onChange={(e) => setProductoId(e.target.value)}
                    >
                        {
                            productos && productos.map(e => {
                                return (
                                <option key={e.Id} value={e.Id}>{e.Nombre} - {e.Stock}</option>
                                )
                            })
                        }
                    </select>
                </div>
                <div className='form-group mb-3'>
                    <label className='mr-2'>Fecha</label>
                    <input 
                        type="date" 
                        onChange={(e) => setFecha(e.target.value)}
                        required
                        />
                </div>
                <div className='form-group mb-3'>
                    <label className='mr-2'>Motivo</label>
                    <input
                        type="text"
                        onChange={(e) => setMotivo(e.target.value)}
                        required
                    />
                </div>
                <div className='form-group mb-3'>
                    <label className='mr-2'>Stock ajustado</label>
                    <input
                        type="number"
                        onChange={(e) => setCantidad(e.target.value)}
                        required
                    />
                </div>

                <button
                    className='btn btn-primary mb-3'
                    type='submit'
                >
                        <i>Aceptar</i>
                </button>
            </form>
            <Link className='btn btn-danger' to='/'>
                <i>Volver a Principal</i>
            </Link>
        </div>
    )
}

export { AjusteStock }
