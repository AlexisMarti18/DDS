import React, { useEffect, useState } from 'react';
import axios from 'axios'
import { Link } from 'react-router-dom';

function ConsultaAjustes() {
    
    const [ajustes, setAjustes] = useState([])

    const cargarAjustes = async () => {
        try {
            const ajs = await axios.get('http://localhost:3001/ajustes')
            setAjustes(ajs.data)
        } catch (error) {
            console.log('NO SE PUDO CARGAR NIGGA:', error)
        }
    }

    useEffect(() => {
        cargarAjustes()
    }, [])

    return (
        <div
            className="table-responsive container p-5"
        >
            <table
                className="table table-primary"
            >
                <thead>
                    <tr>
                        <th scope="col">ProductoId</th>
                        <th scope="col">Fecha</th>
                        <th scope="col">Motivo</th>
                        <th scope="col">CantidadAjuste</th>
                        <th scope="col">StockAnterior</th>
                        <th scope="col">StockNuevo</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        ajustes && ajustes.map((e) => {
                            return (
                                <tr>
                                    <td>{e.Producto_id}</td>
                                    <td>{e.Fecha}</td>
                                    <td>{e.Motivo}</td>
                                    <td>{e.CantidadAjuste}</td>
                                    <td>S anterior</td>
                                    <td>S nuevo</td>
                                </tr>
                            )
                        })
                    }
                </tbody>
            </table>
            <Link className='btn btn-danger' to='/'>
                <i>Volver a Principal</i>
            </Link>
        </div>
        
    )
}

export { ConsultaAjustes }