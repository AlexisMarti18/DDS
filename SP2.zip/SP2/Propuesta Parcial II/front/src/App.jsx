import { useState } from 'react';
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom';
import { Principal } from './components/Principal'
import { AjusteStock } from './components/AjusteStock';
import './App.css'
import { ConsultaAjustes } from './components/ConsultaAjustes';
import { ConsultaProductos } from './components/ConsultaProductos';

function App() {

  return (
    
    <>
      <BrowserRouter>
        <div className='divBody'>
          <Routes>
            <Route path='/' element={<Principal/>}></Route>
            <Route path='/ajuste' element={<AjusteStock/>}></Route>
            <Route path='/consultaAjustes' element={<ConsultaAjustes/>}></Route>
            <Route path='/consultaProductos' element={<ConsultaProductos/>}></Route>
          </Routes>
        </div>
      </BrowserRouter>
    </>
  )
}

export default App
