import sequelize from "./conexion_bd.js";
import app from "./app.js";

const startServer = async () => {
    try {
        await sequelize.sync({force: false});
        console.log("Base de datos sincronizada correctamente")

        app.listen(3001, ()=>{
            console.log(`Servidor inicializado en: https:/localhost:3001`)
          })
          
    } catch (error) {
        console.error(error)
    }
};

startServer()