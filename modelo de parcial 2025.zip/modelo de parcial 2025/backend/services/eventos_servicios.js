import sequelize from "../conexion_bd.js";
import { Op } from "sequelize";

const buscarLugar = async (lugarFiltro) => {
    if (lugarFiltro) {
        const eventosFiltrados = await sequelize.models.Eventos.findAll({
            where: {
                lugar: {[Op.like] : `%${lugarFiltro}%`}
            }
        });

        return eventosFiltrados

    } else {
        return null
    }
};

const eventosServicios = {
    buscarLugar
}

export default eventosServicios