import express from "express";
import cors from "cors";
import eventosRouter from "./routers/eventos_routes.js";

// Configura la aplicación Express
const app = express();
app.use(express.json());

const corsOptions = {
  origin: "*"
}

app.use(cors(corsOptions));

//Definir aqui la ruta con el método GET para obtener todos los eventos según filtro: lugar
app.use("/eventos", eventosRouter)

export default app

