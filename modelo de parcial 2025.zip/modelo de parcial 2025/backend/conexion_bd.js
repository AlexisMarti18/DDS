import { Sequelize } from "sequelize";
import modeloEventos from "./models/Eventos.js";

const sequelize = new Sequelize({
    dialect: "sqlite",
    storage: "./data/bd.sqlite3"
})

//sequelize.define(nombre, atributos, metodos)
sequelize.define("Eventos", modeloEventos.eventosAtributos, modeloEventos.eventosMetodos);

export default sequelize