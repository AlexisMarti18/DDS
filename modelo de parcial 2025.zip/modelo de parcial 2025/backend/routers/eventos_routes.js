import express from "express";
import eventosServicios from "../services/eventos_servicios.js";

const eventosRouter = express.Router();

eventosRouter.get("/buscarLugar", async (req, res) => {
    try {
        const usuariosFiltrados = await eventosServicios.buscarLugar(req.query.lugar);

        if (usuariosFiltrados === null) {
            res.status(400).json({ mensaje: "Falta el parámetro 'lugar' en la query" });
        }

        res.status(200).json(usuariosFiltrados)

    } catch (error) {
        console.error(error);
        res.status(400).json({ mensaje: `Oops, algo salió mal`, error: error })
    }  
});

export default eventosRouter