import { DataTypes } from "sequelize";

const eventosAtributos = {
    id: {
        primaryKey: true,
        type: DataTypes.INTEGER,
        autoIncrement: true
    },

    nombre: {
        type: DataTypes.TEXT,
        allowNull : false
    }, 

    fecha: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
        allowNull : false
    },

    lugar: {
        type: DataTypes.TEXT,
        allowNull : false
    }, 

    enlace: {
        type: DataTypes.TEXT,
        defaultValue: "Sin enlace"
    } 
};

const eventosMetodos = {
    timestamps: false
};

const modeloEventos = {
    eventosAtributos,
    eventosMetodos
};

export default modeloEventos