//completar

const form = document.getElementById("form-filtro");
form.addEventListener("submit", async(event) => {
    event.preventDefault()
    try {  
        const response = await fetch(`http://localhost:3001/eventos/buscarLugar?lugar=${form.lugar.value}`);
        const data = await response.json();

        const tbody = document.getElementById("cuerpo-tabla");
        tbody.innerHTML = ``
        data.forEach(evento => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${evento.nombre}</td>
                <td>${evento.lugar}</td>
                <td>${evento.fecha}</td>
                <td>${evento.enlace}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error(error)
    };
})